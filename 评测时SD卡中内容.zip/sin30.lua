

if math.sin(math.rad(30)) == 0.5 then
	return 0
else
	return -1
end


