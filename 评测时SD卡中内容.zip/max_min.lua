

if math.max(2, 3, 2, 14, 2, 30, -3) == 30 and math.min(2, 3, 2, 14, 2, 30, -3) == -3 then
	return 0
else 
	return -1
end


