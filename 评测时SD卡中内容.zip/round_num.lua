

if math.floor(5.6) == 5 and math.ceil(5.6) == 6 then
	return 0
else
	return -1
end


